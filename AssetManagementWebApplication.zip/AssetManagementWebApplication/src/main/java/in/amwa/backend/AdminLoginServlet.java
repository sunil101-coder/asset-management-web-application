package in.amwa.backend;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;
/**
 * Servlet implementation class AdminLoginServlet
 */
@WebServlet("/login")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		try {
				// driver class load
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				//create a connection
				Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/assetmanagement","root","@Itp@55word");
				
				Statement st = con.createStatement();
				
				String query="select * from admin where email='"+email+"' and password ='"+password+"'" ;
				ResultSet rs = st.executeQuery(query);
				if(rs.next()) {
					out.print("<h1>" +email+": Welcome to home page </h1></br> ");
					out.print("<h1> Login Succesfull </h1></br> ");
					HttpSession s =request.getSession();
					s.setAttribute(query, s);
					response.sendRedirect("index.jsp");
					
				}
				else {
					out.print("<h1>" +email+": please enter correct mail id</h1></br> ");
					out.print("<h1> Login Failed</h1></br> ");
				}
			rs.close();
			st.close();
			con.close();
		}
		catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.print("<h1> Login Failed because of server exception</h1></br> ");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
