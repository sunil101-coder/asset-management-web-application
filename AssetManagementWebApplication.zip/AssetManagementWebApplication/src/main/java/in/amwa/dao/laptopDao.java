package in.amwa.dao;

public class laptopDao {

	private String jdbcurl ="jdbc:mysql://localhost:3306/assetmanagement","root","@Itp@55word";
}
