package in.amwa.dao;

import java.sql.*;

import org.apache.catalina.User;

import in.amwa.entites.user;

import in.amwa.helper.ConnectionProvider;

public class admindao {
	private Connection con;

	public admindao(Connection con) {
		this.con = con;
	}
// method to insert to database

public  User getAdminByEmailAndPassword(String email,String password) {
User user= null;

{
}
}
