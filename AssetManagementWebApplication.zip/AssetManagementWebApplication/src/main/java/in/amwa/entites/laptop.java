package in.amwa.entites;

public class laptop {

	private int LaptopId;
	private String LaptopManufacture;
	private String LaptopModal;
	private String LaptopServiceTag;
	private String LaptopState;
	private String LaptopAssigned;
	private int userid;

	public laptop(int laptopId, String laptopManufacture, String laptopModal, String laptopServiceTag,
			String laptopState, String laptopAssigned, int userid) {
		super();
		LaptopId = laptopId;
		LaptopManufacture = laptopManufacture;
		LaptopModal = laptopModal;
		LaptopServiceTag = laptopServiceTag;
		LaptopState = laptopState;
		LaptopAssigned = laptopAssigned;
		this.userid = userid;
	}

	public int getLaptopId() {
		return LaptopId;
	}

	public void setLaptopId(int laptopId) {
		LaptopId = laptopId;
	}

	public String getLaptopManufacture() {
		return LaptopManufacture;
	}

	public void setLaptopManufacture(String laptopManufacture) {
		LaptopManufacture = laptopManufacture;
	}

	public String getLaptopModal() {
		return LaptopModal;
	}

	public void setLaptopModal(String laptopModal) {
		LaptopModal = laptopModal;
	}

	public String getLaptopServiceTag() {
		return LaptopServiceTag;
	}

	public void setLaptopServiceTag(String laptopServiceTag) {
		LaptopServiceTag = laptopServiceTag;
	}

	public String getLaptopState() {
		return LaptopState;
	}

	public void setLaptopState(String laptopState) {
		LaptopState = laptopState;
	}

	public String getLaptopAssigned() {
		return LaptopAssigned;
	}

	public void setLaptopAssigned(String laptopAssigned) {
		LaptopAssigned = laptopAssigned;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

}
