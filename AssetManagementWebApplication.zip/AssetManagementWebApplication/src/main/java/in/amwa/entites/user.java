package in.amwa.entites;
import java.sql.*;
public class user {
	
	private int idadmin;
	private String email;
	private String password;
	public user(int idadmin, String email, String password) {
		super();
		this.idadmin = idadmin;
		this.email = email;
		this.password = password;
	}
	public user() {
		
	}
	public int getIdadmin() {
		return idadmin;
	}
	public void setIdadmin(int idadmin) {
		this.idadmin = idadmin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public user(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	
	
	
}
